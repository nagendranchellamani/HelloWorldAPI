﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using HelloWorldWebAPI.Controllers;
using System.Web.Mvc;
using HelloWorldHelper.Interfaces;
using Moq;

namespace HelloWorldWebAPI.Tests.Controllers
{
    [TestClass]
    public class HelloWorldControllerTest
    {
        [TestMethod]
        public void HelloWorldPageTest()
        {
            // Arrange
            Mock<IFileIO> fileIO = new Mock<IFileIO>();
            fileIO.Setup(x => x.ReadFile(It.IsAny<string>(), It.IsAny<bool>())).Returns("Hello World!");

            HelloWorldController controller = new HelloWorldController(fileIO.Object);

            // Act
            ViewResult result = controller.HelloWorldPage() as ViewResult;

            // Assert
            Assert.IsNotNull(result);
            Assert.AreEqual("Hello World Page", result.ViewBag.Title);
            Assert.AreEqual("Hello World!", result.ViewBag.Message);
        }
    }
}
