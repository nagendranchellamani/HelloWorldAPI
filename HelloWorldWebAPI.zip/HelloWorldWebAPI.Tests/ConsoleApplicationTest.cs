﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace HelloWorldWebAPI.Tests
{
    [TestClass]
    public class ConsoleApplicationTest
    {
        [TestMethod]
        public void GetHelloWorldDataTest()
        {
            // Arrange
            string path = ConsoleApplication.Program.Path;

            // Act
            string data = ConsoleApplication.Program.GetHelloWorldData(path);

            // Assert
            Assert.AreEqual("Hello World!", data);
        }
    }
}
