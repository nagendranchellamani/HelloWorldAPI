﻿
using HelloWorldHelper.Interfaces;
using HelloWorldHelper.Models;
using System.Web.Configuration;

namespace HelloWorldWebAPI.Models
{
    public class HelloWorldViewModel
    {        
        public string HelloWorldData { get; set; }

        IFileIO _fileIOmodel;

        public HelloWorldViewModel(IFileIO fileIOmodel)
        {
            _fileIOmodel = fileIOmodel;
            HelloWorldData = _fileIOmodel.ReadFile(WebConfigurationManager.AppSettings["HelloWorldDataFile"]);
        }
    }
}