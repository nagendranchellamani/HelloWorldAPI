﻿using HelloWorldHelper.Interfaces;
using HelloWorldHelper.Models;
using HelloWorldWebAPI.Models;
using System.Web.Mvc;

namespace HelloWorldWebAPI.Controllers
{
    public class HelloWorldController : Controller
    {
        private string APItoken; //To implement Authentication  API token string will be used to compare from the request
                
        public HelloWorldViewModel helloWorldVM; //Data Model

        public HelloWorldController()
        {
            FileIOModel fileIOmodel = new FileIOModel();
            helloWorldVM = new HelloWorldViewModel(fileIOmodel);
        }

        public HelloWorldController(IFileIO fileIO)
        {
            helloWorldVM = new HelloWorldViewModel(fileIO);
        }

        public ActionResult HelloWorldPage()
        {           
            ViewBag.Title = "Hello World Page";
            ViewBag.Message = helloWorldVM.HelloWorldData;

            return View();
        }        
    }
}