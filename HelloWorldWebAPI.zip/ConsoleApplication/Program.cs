﻿using HelloWorldHelper.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication
{
    public class Program
    {
        public static string Path = "\\data\\HelloWorldData.txt";

        public static void Main(string[] args)
        {
            string data;

            data = GetHelloWorldData(Path);

            Console.WriteLine(data);

            Console.ReadLine();

        }

        public static string GetHelloWorldData(string path)
        {
            FileIOModel fileIOmodel = new FileIOModel();
            return fileIOmodel.ReadFile(path, true);
        }
    }
}
