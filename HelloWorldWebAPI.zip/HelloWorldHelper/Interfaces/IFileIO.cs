﻿using System;
// Interface for the File I/O
namespace HelloWorldHelper.Interfaces
{
    public interface IFileIO
    {
        /// <summary>
        ///     Reads the file from the file path provided
        /// </summary>
        /// <param name="filePath">File path</param>
        /// <param name="isConsole">isConsole [optional]</param>
        /// <returns>The contents of the file</returns>
        string ReadFile(string filePath, bool isConsole = false);
    }
}
