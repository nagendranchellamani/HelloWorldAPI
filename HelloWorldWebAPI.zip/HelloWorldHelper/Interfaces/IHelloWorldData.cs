﻿//Interface for HelloWorldData
namespace HelloWorldHelper.Interfaces
{
    public interface IHelloWorldData
    {
        /// <summary>
        /// Gets the Hello World Data
        /// </summary>
        /// <returns>Data String</returns>
        string GetHelloWorldData();
    }
}
