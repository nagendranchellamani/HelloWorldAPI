﻿using System;
//Interface for AppSettings
namespace HelloWorldHelper.Interfaces
{
    public interface IAppSettings
    {
        string GetPath(string name);
    }
}
