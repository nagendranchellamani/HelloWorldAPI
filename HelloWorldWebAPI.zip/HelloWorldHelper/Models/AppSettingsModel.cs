﻿using HelloWorldHelper.Interfaces;
using System.Configuration;

namespace HelloWorldHelper.Models
{
    public class AppSettingsModel : IAppSettings
    {        
        public string GetPath(string name)
        {
            return ConfigurationManager.AppSettings.Get(name);
        }
    }
}
