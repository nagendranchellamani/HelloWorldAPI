﻿using HelloWorldHelper.Interfaces;

namespace HelloWorldHelper.Models
{
    public class HelloWorldDataModel : IHelloWorldData
    {
        public const string HelloWorldDataFileKey = "HelloWorldDataFile";

        private readonly IFileIO _fileIOmodel;

        private readonly IAppSettings _appSettings;

        public HelloWorldDataModel(IAppSettings appSettings, IFileIO fileIO)
        {
            _appSettings = appSettings;
            _fileIOmodel = fileIO;
        }

        public string GetHelloWorldData()
        {
            // Get the file path
            var filePath = _appSettings.GetPath(HelloWorldDataFileKey);

            if (string.IsNullOrEmpty(filePath))
            {
                // throw exception if Null
                throw null;
            }

            // Get the data from the file
            var data = _fileIOmodel.ReadFile(filePath);

            return data;
        }
    }
}
