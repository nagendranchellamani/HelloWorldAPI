﻿using System;
using HelloWorldHelper.Interfaces;
using System.IO;
using System.Web.Hosting;

namespace HelloWorldHelper.Models
{
    /// <summary>
    ///  Service for text file IO
    /// </summary>
    public class FileIOModel : IFileIO
    {
        public FileIOModel()
        {
            //Default ctor
        }

        public FileIOModel(string path)
        {
            HostingEnvironment.MapPath("~/" + path);
        }

        /// <summary>
        ///  Reads the file content
        /// </summary>
        /// <param name="filePath">file path</param>
        /// <param name="IsConsole">bool for handle Console</param>
        /// <returns>The data of the file</returns>
        public string ReadFile(string filePath, bool IsConsole = false)
        {
            string fileDatas;
            string serverPath;

            if (IsConsole)
            {
                // For Console or Windows Application
                serverPath = Environment.CurrentDirectory + filePath;
            }
            else
            {
                // Map path to Server path
                serverPath = HostingEnvironment.MapPath("~/" + filePath);
            }            

            try
            {
                using (var reader = new StreamReader(serverPath))
                {
                    fileDatas = reader.ReadToEnd();
                }
            }
            catch (Exception ex)
            {
                // Throw an IO exception
                throw new IOException("Error Reading the Data", new IOException("There was a problem reading the data file!", ex));
            }

            return fileDatas;
        }
    }
}
